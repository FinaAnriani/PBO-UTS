/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author FLOW
 */
public class Penjahit extends Database{
    private String id;
    private String nama;
    private String noHp;

    public Penjahit(String id, String nama, String noHp) {
        this.id = id;
        this.nama = nama;
        this.noHp = noHp;
    }
    
    public DefaultTableModel read() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try {
            openConnection();

            String query = "SELECT * FROM penjahit";
            preparedStatement = getConnection().prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            model.addColumn("ID");
            model.addColumn("Nama");
            model.addColumn("Telepon");

            while (resultSet.next()) {
                this.id = resultSet.getString("id_penjahit");
                this.nama = resultSet.getString("nama_penjahit");
                this.noHp = resultSet.getString("no_hp");

                model.addRow(new Object[]{id, nama, noHp});
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }

        return model;
    }
    
    private boolean idPenjahitExists() {
        try {
            String checkQuery = "SELECT COUNT(*) FROM penjahit WHERE id_penjahit = ?";
            preparedStatement = getConnection().prepareStatement(checkQuery);
            preparedStatement.setString(1, id);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; 
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        }
        return false; 
    }
    
    public boolean create() {
        try {
            openConnection();

            if (idPenjahitExists()) {
                JOptionPane.showMessageDialog(null, "ID penjahit sudah ada", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            String query = "INSERT INTO penjahit (id_penjahit, nama_penjahit, no_hp) VALUES (?, ?, ?)";
            preparedStatement = getConnection().prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, nama);
            preparedStatement.setString(3, noHp);

            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true;
    }

    public boolean update() {
        try {
            openConnection();

            if (!idPenjahitExists()) {
                JOptionPane.showMessageDialog(null, "ID penjahit tidak ditemukan", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            String query = "UPDATE penjahit SET nama_penjahit=?, no_hp=? WHERE id_penjahit=?";
            preparedStatement = getConnection().prepareStatement(query);
            preparedStatement.setString(1, nama);
            preparedStatement.setString(2, noHp);
            preparedStatement.setString(3, id);

            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true;
    }

    public boolean delete() {
        try {
            openConnection();

            if (!idPenjahitExists()) {
                JOptionPane.showMessageDialog(null, "ID penjahit tidak ditemukan", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            String query = "DELETE FROM penjahit WHERE id_penjahit=?";
            preparedStatement = getConnection().prepareStatement(query);
            preparedStatement.setString(1, id);

            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true;
    }
}