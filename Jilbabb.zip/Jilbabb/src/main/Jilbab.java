/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author FLOW
 */
public class Jilbab extends Database{
    private String id;
    private String merk;
    private String jenis;
    private int stok;
    private String warna;
    private int harga;
    private String deskripsi;

    public Jilbab(String id, String merk, String jenis, int stok, String warna, int harga, String deskripsi) {
        this.id = id;
        this.merk = merk;
        this.jenis = jenis;
        this.stok = stok;
        this.warna = warna;
        this.harga = harga;
        this.deskripsi = deskripsi;
    }
    
    public DefaultTableModel read() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try {
            openConnection();

            String query = "SELECT * FROM data_jilbab";
            preparedStatement = getConnection().prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            model.addColumn("ID");
            model.addColumn("Merk");
            model.addColumn("Jenis");
            model.addColumn("Stok");
            model.addColumn("Warna");
            model.addColumn("Harga");
            model.addColumn("Deskripsi");

            while (resultSet.next()) {
                this.id = resultSet.getString("id_jilbab");
                this.merk = resultSet.getString("merk_jilbab");
                this.jenis = resultSet.getString("jenis_jilbab");
                this.stok = resultSet.getInt("stok");
                this.warna = resultSet.getString("warna");
                this.harga = resultSet.getInt("harga");
                this.deskripsi = resultSet.getString("deskripsi");

                model.addRow(new Object[]{id, merk, jenis, stok, warna, harga, deskripsi});
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }

        return model;
    }
    
    private boolean idJilbabExists() {
        try {
            String checkQuery = "SELECT COUNT(*) FROM data_jilbab WHERE id_jilbab = ?";
            preparedStatement = getConnection().prepareStatement(checkQuery);
            preparedStatement.setString(1, id);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; 
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        }
        return false; 
    }
    
    public boolean create() {
        try {
            openConnection();
            
            if (idJilbabExists()) {
            JOptionPane.showMessageDialog(null, "Data jilbab sudah ada.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return false;
        }

            String query = "INSERT INTO `data_jilbab`(`Merk_Jilbab`, `Jenis_Jilbab`, `Stok`, `Warna`, `Harga`, `Deskripsi`) VALUES (?, ?, ?, ?, ?, ?)";
preparedStatement = getConnection().prepareStatement(query);

preparedStatement.setString(1, merk);
preparedStatement.setString(2, jenis);
preparedStatement.setInt(3, stok);
preparedStatement.setString(4, warna);
preparedStatement.setInt(5, harga);
preparedStatement.setString(6, deskripsi);

preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true;
    }
    
    public boolean update() {
        try {
            openConnection();

            String query = "UPDATE `data_jilbab` SET `Merk_Jilbab`=?,`Jenis_Jilbab`=?,`Stok`=?,"
                    + "`Warna`=?,`Harga`=?,`Deskripsi`=? WHERE id_jilbab = ?";
            preparedStatement = getConnection().prepareStatement(query);

            preparedStatement.setString(1, merk);
            preparedStatement.setString(2, jenis);
            preparedStatement.setInt(3, stok);
            preparedStatement.setString(4, warna);
            preparedStatement.setInt(5, harga);
            preparedStatement.setString(6, deskripsi);
            preparedStatement.setString(7, id);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected == 0) {
                // Notify that ID was not found
                JOptionPane.showMessageDialog(null, "ID Jilbab tidak ditemukan.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return false;
            }

        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true;
    }
    
    public boolean delete() {
        try {
            openConnection();

            if (idJilbabExists()) {
                String query = "DELETE FROM `data_jilbab` WHERE id_jilbab = ?";
                preparedStatement = getConnection().prepareStatement(query);
                preparedStatement.setString(1, id);

                preparedStatement.executeUpdate();
            } else {
                JOptionPane.showMessageDialog(null, "ID jilbab tidak ditemukan", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return false;
            }

        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
        return true; 
    }

}
    
